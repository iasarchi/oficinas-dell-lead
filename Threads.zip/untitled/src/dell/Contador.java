package dell;

public class Contador extends Thread {

    String threadName;

    public Contador(String threadName) {
        this.threadName = threadName;
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 50; i++) {
            new Contador(String.valueOf(i)).start();
        }
    }

    @Override
    public void run() {
        for (int i = 1; i <= 500; i++) {
            System.out.println("Thread " + this.threadName + "contando: " + i);
        }
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
